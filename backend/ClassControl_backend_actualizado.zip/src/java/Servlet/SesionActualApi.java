package Servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Permite a la app Flutter preguntar "sigo logueado?" cuando se abre,
 * usando la cookie JSESSIONID que ya deberia tener guardada.
 */
@WebServlet("/api/SesionActual")
public class SesionActualApi extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("id_usuario") == null) {
            ApiUtil.enviarError(response, HttpServletResponse.SC_UNAUTHORIZED, "No hay sesion activa.");
            return;
        }

        String json = "{"
                + "\"success\":true,"
                + "\"idUsuario\":" + session.getAttribute("id_usuario") + ","
                + "\"nombres\":\"" + ApiUtil.escapar((String) session.getAttribute("nombres")) + "\","
                + "\"apellidos\":\"" + ApiUtil.escapar((String) session.getAttribute("apellidos")) + "\","
                + "\"username\":\"" + ApiUtil.escapar((String) session.getAttribute("username")) + "\","
                + "\"rolId\":" + session.getAttribute("rol") + ","
                + "\"rolNombre\":\"" + ApiUtil.escapar((String) session.getAttribute("rol_nombre")) + "\""
                + "}";
        ApiUtil.enviarJson(response, HttpServletResponse.SC_OK, json);
    }
}
