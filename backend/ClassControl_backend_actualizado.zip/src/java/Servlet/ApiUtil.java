package Servlet;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Utilidades compartidas para que los servlets puedan responder tanto al
 * frontend JSP clásico (redirects) como a la app Flutter (JSON), sin
 * duplicar servlets.
 *
 * La app Flutter marca sus peticiones con el header "Accept: application/json".
 * Si ese header está presente, los servlets base responden JSON en vez de
 * hacer sendRedirect. El frontend JSP no manda ese header, así que su
 * comportamiento no cambia en nada.
 */
public final class ApiUtil {

    private ApiUtil() { }

    public static boolean esApi(HttpServletRequest request) {
        String accept = request.getHeader("Accept");
        return accept != null && accept.contains("application/json");
    }

    public static void enviarJson(HttpServletResponse response, int status, String json) throws IOException {
        response.setStatus(status);
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.print(json);
        }
    }

    public static void enviarOk(HttpServletResponse response, String tipo) throws IOException {
        enviarJson(response, HttpServletResponse.SC_OK, "{\"success\":true,\"tipo\":\"" + escapar(tipo) + "\"}");
    }

    public static void enviarError(HttpServletResponse response, int status, String mensaje) throws IOException {
        enviarJson(response, status, "{\"success\":false,\"error\":\"" + escapar(mensaje) + "\"}");
    }

    public static String escapar(String valor) {
        if (valor == null) return "";
        return valor
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }
}
